import React from 'react'

const Search = () => {
  return (
    <div className="flex flex-nowrap bg-[#1B1A1F] w-3/4 h-10 rounded-lg border-1">

    </div>
  )
}

export default Search